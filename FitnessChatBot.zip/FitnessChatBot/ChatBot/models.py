from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
# Create your models here.

class Conversation(models.Model):

    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=255, null=True)
    private_info = models.TextField(null=True, blank=True)
    started = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.username

class QuestionAnswer(models.Model):

    user = models.ForeignKey(User, on_delete = models.CASCADE)
    question = models.TextField(blank=True, null=True)
    answer = models.TextField(blank=True, null=True)
    timestamp = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return str(self.timestamp)