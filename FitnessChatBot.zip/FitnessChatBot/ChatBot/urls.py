from django.urls import path
from . import views
app_name='ChatBot'

urlpatterns = [
    #chatbot api
    path('messages/', views.QuestionAnswerView.as_view()), # done
    path('question/', views.QuestionAnswerView.as_view()), # done
    path('messages/delete/', views.QuestionAnswerView.as_view()), # done
    #authentication
    path('register/', views.register_user, name="register_user"),
    path('logout/',views.logout_user, name='logout_user'),
    path('login/',views.login_user, name="login_user"),
    path('authenticate/',views.authenticateion_check, name='authenticateion_check'),
    path('key/public/',views.get_public_key, name='get_public_key'),
]