import base64
import openai
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializers import ConversationSerializer, QuestionAnswerSerializer
from .models import Conversation, QuestionAnswer
from rest_framework import status
from rest_framework import permissions
import json
from django.conf import settings
from django.http import JsonResponse
from .filter_sentence import predict

from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from rest_framework.views import APIView
from rest_framework import status
from django.views.decorators.csrf import csrf_protect,csrf_exempt
from django.db import IntegrityError
from django.utils.decorators import method_decorator

from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend

from Crypto.Cipher import AES

# Create your views here.
@method_decorator(csrf_protect, name='dispatch')
class ConversationView(APIView):

    permission_classes = [permissions.IsAuthenticated]

    def put(self, request):

        try:
            conversation = Conversation.objects.get(username = request.user.id)
        except Conversation.DoesNotExist:
            return Response(status=status.HTTP_304_NOT_MODIFIED)
    # handle the case where the object does not exist
        else:
            if(conversation is None):
                return Response(status=status.HTTP_304_NOT_MODIFIED)
            body_unicode = request.body.decode('utf-8')
            body_data = json.loads(body_unicode)
            private_info = body_data.get('private_info', None)


            data = {
                'private_info': private_info
            }

            serializer = ConversationSerializer(conversation, data=data)

            if serializer.is_valid():
                serializer.save()
                return Response(status=status.HTTP_200_OK)

            return Response(status=status.HTTP_304_NOT_MODIFIED)
    
    def delete(self, request):
        try:
            conversation = Conversation.objects.get(username = request.user.id)
        except Conversation.DoesNotExist:
            return Response(status=status.HTTP_406_NOT_ACCEPTABLE)
        
        data = {
            'private_info': None
        }

        serializer = ConversationSerializer(conversation, data=data)

        if serializer.is_valid():
            serializer.save()
            return Response(status=status.HTTP_200_OK)

        return Response(status=status.HTTP_304_NOT_MODIFIED)
    
@method_decorator(csrf_protect, name='dispatch')
class QuestionAnswerView(APIView):

    permission_classes = [permissions.IsAuthenticated]

    # get history of conversation
    def get(self, request):
        QA = QuestionAnswer.objects.filter(user = request.user.id)
        serializer = QuestionAnswerSerializer(QA, many=True)

        return Response({"conversation":serializer.data}, status=status.HTTP_200_OK)     

    def post(self,request): # Tạo 1 cặp question-answer mới
        response_body ={}
        private_info = False
        private_info_str = ''

        body_unicode = request.body.decode('utf-8')
        body_data = json.loads(body_unicode)
        question = body_data.get('question', None)
        encrypted_private_info = body_data.get('private_info', None)
        encrypted_key = body_data.get('encrypted_key', None)

        if(encrypted_private_info is not None and encrypted_key is not None):
            private_info_str = get_private_info_plaintext(encrypted_key, encrypted_private_info)

        question_embedded_private_info = ''
        if(private_info_str is not None and private_info_str != ''):
            question_embedded_private_info = private_info_str + '\n' + question
            private_info = True
        
        print("question: ", question)

        if predict(question) is False: 
            response_body['answer'] = None
            response_body['private_info'] = private_info
            response_body['valid_question'] = False
            return JsonResponse(response_body, status=status.HTTP_204_NO_CONTENT)
        
        answer = ''
        if(private_info is True):
            answer = ChatGPT(question_embedded_private_info)
        else:
            answer = ChatGPT(question)

        print(answer)

        record_data = {
            'question': question, 
            'user': request.user.id,
            'answer': answer,
        }

        response_body['answer'] = answer
        response_body['private_info'] = private_info
        response_body['valid_question'] = True

        serializer = QuestionAnswerSerializer(data=record_data)

        if serializer.is_valid():
            serializer.save()
            return JsonResponse(response_body, status=status.HTTP_200_OK)

        return Response(status=status.HTTP_406_NOT_ACCEPTABLE)

    def delete(self, request): #done

        QA_instance = QuestionAnswer.objects.filter(user = request.user.id)

        if not QA_instance:
            return Response(status=status.HTTP_406_NOT_ACCEPTABLE)

        QA_instance.delete()
        return Response(status=status.HTTP_200_OK)

#login, logout, register and authentication check

# authenticate check
@csrf_exempt
def authenticateion_check(request):
    if request.user.is_authenticated:
        try:
            con = Conversation.objects.get(username = request.user.id)
        except Conversation.DoesNotExist:
            return JsonResponse({'is_authenticated': False})
        else:
            if(con.private_info is None):
                return JsonResponse({'is_authenticated': True,
                             'username': request.user.username,
                             'private_info': False})
            else:
                return JsonResponse({'is_authenticated': True,
                             'username': request.user.username,
                             'private_info': True})
    else:
        return JsonResponse({'is_authenticated': False})
    
# login
@csrf_exempt
def login_user(request):
    if request.user.is_authenticated:
        return JsonResponse({'is_authenticated': True})
    else:
        if request.method == 'POST':
            # Parse JSON data from request body
            body_unicode = request.body.decode('utf-8')
            body_data = json.loads(body_unicode)
            username = body_data['username']
            password = body_data['password']
            user = authenticate(request, username=username, password=password)      
            if user is not None:
                login(request, user)
                return JsonResponse({'is_authenticated': True})
            else:
                return JsonResponse({'is_authenticated': False})

        else:
            return JsonResponse({'is_authenticated': False})


# logout
@csrf_protect
def logout_user(request):
    if request.user.is_authenticated:
        logout(request)
        return JsonResponse({'logout': 'succeed'}, status=status.HTTP_200_OK)
    return JsonResponse({'logout': 'failed'}, status=status.HTTP_400_BAD_REQUEST)

# register
@csrf_exempt
def register_user(request):
    if request.method == 'POST':
        # Parse JSON data from request body
        body_unicode = request.body.decode('utf-8')
        body_data = json.loads(body_unicode)
        # Get the user input from the POST request
        username = body_data['username']
        password = body_data['password']
        email = body_data['email']

        # Create the new user
        try:
            user = User.objects.create_user(username=username, email=email, password=password)
            
        except IntegrityError:
            return JsonResponse(data={"register":"failed"},status=status.HTTP_403_FORBIDDEN) 
        else:
            user.save()
            # authenticated_user = authenticate(username=username,password=password)
            data = {
                'username': user.id
            }
            serializer = ConversationSerializer(data=data)
            if not serializer.is_valid():
                print("Failed to create a new conversation for the user")
                return JsonResponse(data={"register":"failed"},status=status.HTTP_403_FORBIDDEN) 
            else:
                serializer.save()            
                print("Successfully created a new conversation for the user")
                return JsonResponse(data={"register":"succeeded"},status=status.HTTP_201_CREATED)
    else:
        return JsonResponse(data={"register":"failed"},status=status.HTTP_405_METHOD_NOT_ALLOWED)

# chatGPT openai
def ChatGPT(question):
    model = "text-davinci-003"
    openai.api_key= settings.OPENAI_API_KEY
    response = openai.Completion.create(engine=model, temperature=1, prompt=question, max_tokens=3000, n=1)
    answer = response.choices[0].text
    return answer

# get public key
@csrf_exempt
def get_public_key(request):
    if request.method == 'GET':
        with open('./Chatbot/key/public_key.pem', 'rb') as public_key_file:
            public_key = public_key_file.read().decode('utf-8')
        return JsonResponse({'public_key': public_key})
    else:
        return JsonResponse({'public_key': None})

def decrypt_aes_128(key, ciphertext):
    cipher = AES.new(key, AES.MODE_ECB)
    decrypted_data = cipher.decrypt(ciphertext)
    return decrypted_data
    
def get_private_info_plaintext(encrypted_key, encrypted_private_info):
    with open('./Chatbot/key/private_key.pem', 'rb') as key_file:
        private_key = serialization.load_pem_private_key(
        key_file.read(),
        password=None,  # If the private key is password-protected, provide the password
        backend=default_backend()
        )
    
    encrypted_key = base64.b64decode(encrypted_key)

    decrypted_key = private_key.decrypt(
        encrypted_key,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )

    encrypted_private_info = base64.b64decode(encrypted_private_info)

    plaintext_private_info = decrypt_aes_128(decrypted_key, encrypted_private_info)
    string_data = plaintext_private_info.decode('utf-8', errors='replace')
    print(string_data)

    return string_data
    