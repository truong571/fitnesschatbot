from django.contrib import admin
from .models import Conversation, QuestionAnswer
# Register your models here.


class ConversationAdmin(admin.ModelAdmin):

    list_display = ('id', 'username', 'private_info','started')

class QuestionAnswerAdmin(admin.ModelAdmin):

    list_display = ('user', 'timestamp')

admin.site.register(Conversation, ConversationAdmin)
admin.site.register(QuestionAnswer, QuestionAnswerAdmin)