import { resolve } from 'path'
import { defineConfig } from 'vite'
import redirect from 'vite-plugin-redirect'

const root = resolve(__dirname, './')

// https://vitejs.dev/config/
export default defineConfig({
  server: {
    host: '127.0.0.1',
    root,
    plugins: [
      redirect({
        '/chatbot': '/chatbot/',
        '/info/export': '/info/export/',
        '/info/import': '/info/import/',
        '/authenticate/login': '/authenticate/login/',
        '/authenticate/register': '/authenticate/register/',
      }),
    ],
    open: '/chatbot/',
    build: {
      rollupOptions: {
        input: {
          'chabot': resolve(root, 'chatbot/index.html'),
          'info/export': resolve(root, 'info/export/index.html'),
          'info/import': resolve(root, 'info/import/index.html'),
          'authenticate/login': resolve(root, 'authenticate/login/index.html'),
          'authenticate/register': resolve(root, 'authenticate/register/index.html'),
        }
      }
    }
  }
})
