const BASE_URL = `http://${window.location.hostname}:${window.location.port}`;

const SERVER_PORT = 8000;
const SERVER_URL = `http://127.0.0.1:${SERVER_PORT}/chatbot`;

// Fetch username information from /chatbot/authenticate/
export async function checkAuthenticationAndRedirect(redirectTo) {
  fetch(`${SERVER_URL}/authenticate/`, {
    credentials: 'include',
    mode: 'cors'
  })
    .then(response => {
      if (response.ok) {
        return response.json();
      }
      else {
        window.location.href = `${BASE_URL}/authenticate/login/?redirect=${redirectTo}`;
      }
    })
    .then(data => {
      if (!data.is_authenticated) {
        window.location.href = `${BASE_URL}/authenticate/login/?redirect=${redirectTo}`;
      }
    });
}

export function getCSRFToken() {
  const name = 'csrftoken';
  const cookieValue = document.cookie
    .split(';')
    .find((cookie) => cookie.trim().startsWith(`${name}=`));
  if (cookieValue) {
    return cookieValue.split('=')[1];
  }
  return null;
}
