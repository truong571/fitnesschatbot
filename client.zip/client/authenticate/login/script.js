const SERVER_PORT = 8000;
const BASE_URL = `http://${window.location.hostname}:${window.location.port}`;

const SERVER_LOGIN_URL = `http://127.0.0.1:${SERVER_PORT}/chatbot/login/`;

// Get the Login button element
const loginBtn = document.querySelector('button[type="submit"]')

// Add an onclick event listener
loginBtn.addEventListener('click', function (event) {
  // Prevent the default form submission behavior
  event.preventDefault();

  // Get the username and password input values
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  // Call the login function with the username and password
  login(username, password)
})


// Login function
function login(username, password) {
  console.log('Logging in...');
  const urlParams = new URLSearchParams(window.location.search);
  // Make an API call to authenticate the user
  fetch(SERVER_LOGIN_URL, {
    method: 'POST',
    credentials: 'include',
    body: JSON.stringify({ username, password }),
    headers: {
      'Content-Type': 'application/json',
    }
  })
    .then(response => response.json())
    .then(data => {
      console.log('Data:', data);

      if (data.is_authenticated) {
        const redirect = urlParams.get("redirect") || "/chatbot/";
        window.location.href = `${BASE_URL}${redirect}`;
      }
      else {
        // Show an error message
        const errorSpan = document.getElementById('login-error');
        errorSpan.removeAttribute('hidden');
      }
    })
    .catch(error => console.error(error));
}
