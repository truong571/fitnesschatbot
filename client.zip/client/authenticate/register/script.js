const SERVER_PORT = 8000;
const BASE_URL = `http://${window.location.hostname}:${window.location.port}`;

const SERVER_REGISTER_URL = `http://127.0.0.1:${SERVER_PORT}/chatbot/register/`;

const confirm_password = document.getElementById("confirm-password");
const registerBtn = document.getElementById("register-submit-btn");

confirm_password.addEventListener("keyup", checkPasswordMatch);

registerBtn.addEventListener("click", function (event) {
  event.preventDefault();

  // Get the username and password input values
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const email = document.getElementById('email').value;
  const confirmPassword = document.getElementById('confirm-password').value;

  // Call the register function with the credentials
  register(username, password, email, confirmPassword);

});

function checkPasswordMatch() {
  var password = document.getElementById("password").value;
  var confirmPassword = document.getElementById("confirm-password").value;
  const passwordMatchSpan = document.getElementById("password-match");
  if (password != confirmPassword) {
    passwordMatchSpan.innerHTML = "Passwords do not match";
    passwordMatchSpan.style.color = "red";
  }
  else {
    passwordMatchSpan.innerHTML = "Passwords match";
    passwordMatchSpan.style.color = "green";
  }
}

function register(username, password, email, confirmPassword) {
  console.log('Submitting...');
  // Make an API call to authenticate the user
  fetch(SERVER_REGISTER_URL, {
    method: 'POST',
    credentials: 'include',
    mode: 'cors',
    body: JSON.stringify({ username, password, email }),
    headers: {
      'Content-Type': 'application/json',
    }
  })
    .then(response => response.json())
    .then(data => {
      console.log('Data:', data);
      // If the user is authenticated, save the token in a cookie
      if (data.register === 'succeeded') {

        // Redirect the user to the chat page 
        window.location.href = `${BASE_URL}/authenticate/login/`;
      }
      else if (data.register === 'failed') {
        // Show an error message
        const errorDiv = document.getElementById('register-error');
        errorDiv.removeAttribute('hidden');
      }
      else {
        console.log("Something went wrong. Maybe the server is down?");
      }
    })
    .catch(error => console.error(error));
}
