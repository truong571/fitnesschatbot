import CryptoJS from 'crypto-js';

export function encryptMessage(key, plaintext) {

  let key_word_array = CryptoJS.enc.Utf8.parse(key);
  const encrypted = CryptoJS.AES.encrypt(plaintext, key_word_array, {
    mode: CryptoJS.mode.ECB,
  });
  const ciphertext = encrypted.toString();
  console.log("Ciphertext:", ciphertext);
  return ciphertext;
};

export async function encrypteKey(data, publicKeyPem) {
  const encoder = new TextEncoder();
  const dataBuffer = encoder.encode(data);

  const publicKey = await importPublicKey(publicKeyPem);
  const encryptedData = await encryptWithPublicKey(publicKey, dataBuffer);

  const uint8ArrayEncryptedData = new Uint8Array(encryptedData);
  const base64String = btoa(String.fromCharCode.apply(null, uint8ArrayEncryptedData));
  return base64String;
}

async function importPublicKey(publicKeyPem) {
  const publicKeyData = convertPemToBinary(publicKeyPem);

  const importedKey = await crypto.subtle.importKey(
    'spki',
    publicKeyData,
    {
      name: 'RSA-OAEP',
      hash: 'SHA-256',
    },
    false,
    ['encrypt']
  );

  return importedKey;
}

function convertPemToBinary(pem) {
  const lines = pem.split('\n');
  const encodedKey = lines.slice(1, -1).join('');
  const binaryKey = window.atob(encodedKey);

  const binaryData = new Uint8Array(binaryKey.length);
  for (let i = 0; i < binaryKey.length; ++i) {
    binaryData[i] = binaryKey.charCodeAt(i);
  }

  return binaryData;
}

async function encryptWithPublicKey(publicKey, data) {
  const encryptedData = await crypto.subtle.encrypt(
    {
      name: 'RSA-OAEP',
    },
    publicKey,
    data
  );

  return encryptedData;
}

export function generateRandomKey(length) {
  const characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()';
  let randomString = '';

  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    randomString += characters.charAt(randomIndex);
  }

  return randomString;
}