import { checkAuthenticationAndRedirect, getCSRFToken } from '../../authenticate/check/script.js';

const SERVER_PORT = 8000;
const SERVER_URL = `http://127.0.0.1:${SERVER_PORT}/chatbot`;

await checkAuthenticationAndRedirect("/info/export/");

let private_info_str = '';

// Fetch username information from /chatbot/authenticate/
(function getUsername() {
  fetch(`${SERVER_URL}/authenticate/`, {
    credentials: 'include',
  })
    .then(response => {
      if (response.ok) {
        return response.json();
      }
    })
    .then(data => {
      document.getElementById('username').innerText = data.username;
    });
})();

const encrypt_status = document.getElementById("encrypt-status");
const send_private_data_button = document.getElementById("send-private-data");

const form = document.querySelector('form');
form.addEventListener('submit', function (event) {
  event.preventDefault(); // Prevent form from submitting normally
  submitForm();
});


send_private_data_button.addEventListener("click", () => {

  sessionStorage.setItem("private_info", private_info_str);
  window.location.href = "/chatbot/";
});

// Add click event listener to logout button
document.getElementById('logout').addEventListener('click', () => {
  // Send GET request to /logout/ to log the user out
  fetch(`${SERVER_URL}/logout/`, {
    method: 'GET',
    credentials: 'include',
  })
    .then(response => {
      // Redirect to the login page
      window.location.href = '/authenticate/login/';
      response.json();
    })
    .then(data => console.log(data))
    .catch(error => console.error(error));
});

function submitForm() {
  let form = document.getElementById("myForm");
  let age = form.elements["age"].value;
  let sex = form.elements["sex"].value;
  let height = form.elements["height"].value;
  let weight = form.elements["weight"].value;
  let activity = form.elements["activity"].value;
  let goal = form.elements["goal"].value;
  let password = form.elements["password"].value;
  let confirmpassword = form.elements["confirmpassword"].value;

  private_info_str = `Tôi là ${sex}, ${age} tuổi. Có cân nặng là ${weight} kg và chiều cao là ${height} cm. Tôi có tuần suất hoạt động là ${activity}. Mục tiêu của tôi là ${goal}. Tôi xin hỏi:\n`;

  let isSucceeded = (async () => {
    return await encryptData(private_info_str, password);
  })();

  if (isSucceeded) {
    send_private_data_button.removeAttribute('hidden');
    send_private_data_button.disabled = false;
    encrypt_status.textContent = "Xử lý dữ liệu thành công, bắt đầu trò chuyện ngay!!!";
    encrypt_status.style.color = "green";
  }
  else {
    //Failed
    send_private_data_button.disabled = true;
    encrypt_status.textContent = "Một lỗi bất ngờ đã xảy ra khi lưu trữ dữ liệu";
    encrypt_status.style.color = "red";
  }
}

// save file
function saveToFile(data) {

  var file = new Blob([data], { type: 'text/plain' });
  var a = document.createElement("a");
  var url = URL.createObjectURL(file);
  a.href = url;
  a.download = "encrypted-data.txt";
  document.body.appendChild(a);
  a.click();
  setTimeout(function () {
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  }, 0);
}

//encrypt file
async function encryptData(plaintext, password) {

  const encoder = new TextEncoder();
  const uint8ArrayPlainText = encoder.encode(plaintext);

  var plaintextbytes = new Uint8Array(uint8ArrayPlainText);

  var pbkdf2iterations = 10000;
  var passphrasebytes = new TextEncoder("utf-8").encode(password);
  var pbkdf2salt = window.crypto.getRandomValues(new Uint8Array(8));

  var passphrasekey = await window.crypto.subtle.importKey('raw', passphrasebytes, { name: 'PBKDF2' }, false, ['deriveBits'])
    .catch(function (err) {
      console.error(err);
    });
  console.log('passphrasekey imported');

  var pbkdf2bytes = await window.crypto.subtle.deriveBits({ "name": 'PBKDF2', "salt": pbkdf2salt, "iterations": pbkdf2iterations, "hash": 'SHA-256' }, passphrasekey, 384)
    .catch(function (err) {
      console.error(err);
    });
  console.log('pbkdf2bytes derived');
  pbkdf2bytes = new Uint8Array(pbkdf2bytes);

  var keybytes = pbkdf2bytes.slice(0, 32);
  var ivbytes = pbkdf2bytes.slice(32);

  var key = await window.crypto.subtle.importKey('raw', keybytes, { name: 'AES-CBC', length: 256 }, false, ['encrypt'])
    .catch(function (err) {
      console.error(err);
    });
  console.log('key imported');

  var cipherbytes = await window.crypto.subtle.encrypt({ name: "AES-CBC", iv: ivbytes }, key, plaintextbytes)
    .catch(function (err) {
      console.error(err);
    });

  if (!cipherbytes) {
    alert("Encryption failed");
    console.log("Encryption failed");
  }

  console.log('plaintext encrypted');
  cipherbytes = new Uint8Array(cipherbytes);

  var resultbytes = new Uint8Array(cipherbytes.length + 16)
  resultbytes.set(new TextEncoder("utf-8").encode('Salted__'));
  resultbytes.set(pbkdf2salt, 8);
  resultbytes.set(cipherbytes, 16);

  console.log("encrypted result: " + resultbytes);

  if (resultbytes.length !== 0) {
    saveToFile(resultbytes);
    console.log("Encrypted data successfully saved");
    return true;
  }
  else {
    //alert("Encrypted data failed to save");
    console.log("Encrypted data failed to save");
  }
  return false;
}
