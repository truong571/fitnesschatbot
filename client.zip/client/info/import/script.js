import { checkAuthenticationAndRedirect, getCSRFToken } from '../../authenticate/check/script.js';

const SERVER_PORT = 8000;
const SERVER_URL = `http://127.0.0.1:${SERVER_PORT}/chatbot`;

await checkAuthenticationAndRedirect("/info/import/");
let private_info_str = '';
// Fetch username information from /chatbot/authenticate/
(function getUsername() {
  fetch(`${SERVER_URL}/authenticate/`, {
    credentials: 'include',
  })
    .then(response => {
      if (response.ok) {
        return response.json();
      }
    })
    .then(data => {
      document.getElementById('username').innerText = data.username;
    });
})();

var mode = null;
var objFile = null;

const btnDecrypt = document.getElementById("btnDecrypt");
btnDecrypt.addEventListener('click', (event) => {
  decryptfile();
});

const txtDecpassphrase = document.getElementById("txtDecpassphrase");
txtDecpassphrase.addEventListener('keyup', (event) => {
  decvalidate();
})

const decdropzone = document.getElementById("decdropzone");
decdropzone.addEventListener('drop', (event) => {
  drop_handler(event);
});

decdropzone.addEventListener('dragover', (event) => {
  dragover_handler(event);
});

decdropzone.addEventListener('dragend', (event) => {
  dragend_handler(event);
});

const decfileElem = document.getElementById("decfileElem");
decfileElem.addEventListener('change', (event) => {
  selectfile(decfileElem.files);
});
const spndecfilename = document.getElementById("spndecfilename");
const spnDecstatus = document.getElementById("spnDecstatus");
const decrypted_info_container = document.getElementById("decrypted-info-container");
const sendInfoToServerBtn = document.getElementById("sendInfoToServerBtn");
sendInfoToServerBtn.addEventListener('click', () => {

  sessionStorage.setItem("private_info", private_info_str);

  window.location.href = "/chatbot/";
});
const plaintextArea = document.getElementById("plaintext-area");

//////////////////////////////
function decvalidate() {
  if (txtDecpassphrase.value.length > 0 && objFile) {
    btnDecrypt.disabled = false;
  }
  else {
    btnDecrypt.disabled = true;
  }
}

//drag and drop functions:
//https://developer.mozilla.org/en-US/docs/Web/API/HTML_Drag_and_Drop_API/File_drag_and_drop
function drop_handler(ev) {
  //decvalidate();
  ev.preventDefault();
  // If dropped items aren't files, reject them
  var dt = ev.dataTransfer;
  if (dt.items) {
    // Use DataTransferItemList interface to access the file(s)
    for (var i = 0; i < dt.items.length; i++) {
      if (dt.items[i].kind == "file") {
        var f = dt.items[i].getAsFile();
        objFile = f;
      }
    }
  } else {
    // Use DataTransfer interface to access the file(s)
    for (var i = 0; i < dt.files.length; i++) {
      console.log("... file[" + i + "].name = " + dt.files[i].name);
    }
    objFile = file[0];
  }
  displayfile()
}

function dragover_handler(ev) {
  console.log("dragOver");
  // Prevent default select and drag behavior
  ev.preventDefault();
}

// Add click event listener to logout button
document.getElementById('logout').addEventListener('click', () => {
  // Send GET request to /logout/ to log the user out
  fetch(`${SERVER_URL}/logout/`, {
    method: 'GET',
    credentials: 'include',
  })
    .then(response => {
      // Redirect to the login page
      window.location.href = '/authenticate/login/';
      response.json();
    })
    .then(data => console.log(data))
    .catch(error => console.error(error));
});

function dragend_handler(ev) {
  console.log("dragEnd");
  // Remove all of the drag data
  var dt = ev.dataTransfer;
  if (dt.items) {
    // Use DataTransferItemList interface to remove the drag data
    for (var i = 0; i < dt.items.length; i++) {
      dt.items.remove(i);
    }
  } else {
    // Use DataTransfer interface to remove the drag data
    ev.dataTransfer.clearData();
  }
}

//
function selectfile(Files) {
  objFile = Files[0];
  displayfile()
}

//
function displayfile() {
  var s;
  var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  var bytes = objFile.size;
  var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
  if (i == 0) { s = bytes + ' ' + sizes[i]; } else { s = (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + sizes[i]; }

  spndecfilename.textContent = objFile.name + ' (' + s + ')';
}

//encrypt file
function readfile(file) {
  return new Promise((resolve, reject) => {
    var fr = new FileReader();
    fr.onload = () => {
      resolve(fr.result)
    };
    fr.readAsArrayBuffer(file);
  });
}

//decrypt file
async function decryptfile() {
  btnDecrypt.disabled = true;

  var cipherbytes = await readfile(objFile)
    .catch(function (err) {
      console.error(err);
    });
  var cipherbytes = new Uint8Array(cipherbytes);

  var pbkdf2iterations = 10000;
  var passphrasebytes = new TextEncoder("utf-8").encode(txtDecpassphrase.value);
  var pbkdf2salt = cipherbytes.slice(8, 16);


  var passphrasekey = await window.crypto.subtle.importKey('raw', passphrasebytes, { name: 'PBKDF2' }, false, ['deriveBits'])
    .catch(function (err) {
      console.error(err);

    });
  console.log('passphrasekey imported');

  var pbkdf2bytes = await window.crypto.subtle.deriveBits({ "name": 'PBKDF2', "salt": pbkdf2salt, "iterations": pbkdf2iterations, "hash": 'SHA-256' }, passphrasekey, 384)
    .catch(function (err) {
      console.error(err);
    });
  console.log('pbkdf2bytes derived');
  pbkdf2bytes = new Uint8Array(pbkdf2bytes);

  let keybytes = pbkdf2bytes.slice(0, 32);
  let ivbytes = pbkdf2bytes.slice(32);
  cipherbytes = cipherbytes.slice(16);

  var key = await window.crypto.subtle.importKey('raw', keybytes, { name: 'AES-CBC', length: 256 }, false, ['decrypt'])
    .catch(function (err) {
      console.error(err);
    });
  console.log('key imported');

  var plaintextbytes = await window.crypto.subtle.decrypt({ name: "AES-CBC", iv: ivbytes }, key, cipherbytes)
    .catch(function (err) {
      console.error(err);
    });

  if (!plaintextbytes) {
    spnDecstatus.classList.add("redspan");
    spnDecstatus.innerHTML = '<p>Error decrypting file.  Password may be incorrect.</p>';
    return;
  }

  console.log('ciphertext decrypted');
  plaintextbytes = new Uint8Array(plaintextbytes);

  var blob = new Blob([plaintextbytes], { type: 'application/download' });
  //var blobUrl = URL.createObjectURL(blob);
  console.log(blob);
  blob.text().then(text => {
    private_info_str = text;
    plaintextArea.value = text;
  });

  decrypted_info_container.hidden = false;


  spnDecstatus.classList.add("greenspan");
  spnDecstatus.innerHTML = '<p>Thông tin đã được giải mã.</p>';
}
