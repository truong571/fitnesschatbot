import bot from '/bot.svg';
import user from '/user.svg';
import { checkAuthenticationAndRedirect, getCSRFToken } from '../authenticate/check/script.js';
import { encryptMessage, encrypteKey, generateRandomKey } from '../authenticate/crypto/script.js';

await checkAuthenticationAndRedirect("/chatbot/");

let publicKey = ''

const form = document.querySelector('form');
const chatContainer = document.querySelector('#chat_container');
const private_info_state = document.getElementById("is-private-data-included");

let loadInterval;

const BASE_URL = `http://${window.location.hostname}:${window.location.port}`;
const SERVER_PORT = 8000;
const SERVER_URL = `http://127.0.0.1:${SERVER_PORT}/chatbot`;

// Fetch username information from /chatbot/authenticate/
(function getUsername() {
  if (sessionStorage.getItem('private_info')) {
    if (!private_info_state.classList.contains('on')) {
      private_info_state.classList.add('on');
    }
  }
  else {
    if (private_info_state.classList.contains('on')) {
      private_info_state.classList.remove('on');
    }
  }
})();

// get public key
const getPublicKey = async () => {
  const response = await fetch(`${SERVER_URL}/key/public/`, {
    method: 'GET',
    credentials: 'include',
    mode: 'cors',
  });

  if (response.ok) {
    const data = await response.json();
    publicKey = data.public_key;
  }
}

getPublicKey();

// load chat history
const loadAllMessages = async () => {
  const response = await fetch(`${SERVER_URL}/messages/`, {
    method: 'GET',
    credentials: 'include',
    mode: 'cors',
  });

  if (response.ok) {
    const data = await response.json();
    data.conversation.forEach((message) => {
      chatContainer.innerHTML += chatStripe(false, message.question);
      chatContainer.innerHTML += chatStripe(true, message.answer);
    });
  }
  else {
    const err = await response.text();
  }
};

// call load chat history function
await loadAllMessages();

// Add click event listener to logout button
document.getElementById('logout').addEventListener('click', () => {
  // Send GET request to /logout/ to log the user out
  fetch(`${SERVER_URL}/logout/`, {
    method: 'GET',
    credentials: 'include',
    mode: 'cors',
  })
    .then(response => {
      // Redirect to the login page
      window.location.href = '/authenticate/login/';
      response.json();
    })
    .then(data => console.log(data))
    .catch(error => console.error(error));
});

const importOption = document.querySelector('input[value="import"]');
importOption.addEventListener('click', () => {
  window.location.href = `${BASE_URL}/info/import/`;
});

const exportOption = document.querySelector('input[value="export"]');
exportOption.addEventListener('click', () => {
  window.location.href = `${BASE_URL}/info/export/`;
});

const closeButton = document.getElementById('close');
closeButton.addEventListener('click', () => {
  const popup = document.getElementById('popup-private-info');
  popup.style.display = 'none';
});

const importButton = document.getElementById('import');
importButton.addEventListener('click', () => {
  const popup = document.getElementById('popup-private-info');
  popup.style.display = 'block';
});

const deletePrivateInfoButton = document.getElementById('delete-private-info');
deletePrivateInfoButton.addEventListener('click', () => {
  console.log("delete private info");
  sessionStorage.removeItem('private_info');
  if (private_info_state.classList.contains('on')) {
    private_info_state.classList.remove('on');
  }
});

const resetConversationButton = document.getElementById('reset-chat');
resetConversationButton.addEventListener('click', async () => {
  const response = await fetch(`${SERVER_URL}/messages/delete/`, {
    method: 'DELETE',
    credentials: 'include',
    mode: 'cors',
    headers: {
      'X-CSRFToken': getCSRFToken()
    }
  });

  if (response.ok) {
    if (response.status === 200) {
      //hiển thị việc xóa đoạn chat thành công
      location.reload();
    }
  }
  else {
    //hiển thị việc xóa đoạn chat thất bại
  }

  console.log("reset conversation");
});
function loader(element) {
  element.textContent = '';

  loadInterval = setInterval(() => {
    element.textContent += '.';

    if (element.textContent.length === 6) {
      element.textContent = '';
    }
  }, 500);
}

function typeText(element, text) {
  let index = 0;

  const typeInterval = setInterval(() => {
    if (index < text.length) {
      element.innerHTML += text.charAt(index);
      index++;
    }
    else {
      clearInterval(typeInterval);
    }
  }, 20);
}

function generateUniqueId() {
  const timestamp = (new Date()).getTime();
  const randomNumber = Math.random();
  const hexadecimaString = randomNumber.toString(16);

  return `id-${timestamp}-${hexadecimaString}`;
}

function chatStripe(isAi, value, uniqueId) {
  return (
    `
    <div class="wrapper ${isAi && 'ai'}">
      <div class="chat">
        <div class="profile">
          <img
            src="${isAi ? bot : user}"
            alt="${isAi ? 'bot' : 'user'}"
          />
        </div>
        <div class="message" id=${uniqueId}>${value}</div>
      </div>
    </div>
    `
  )
}

const handleSubmit = async (e) => {
  e.preventDefault();
  const data = new FormData(form);

  //user's chatstripe

  chatContainer.innerHTML += chatStripe(false, data.get('prompt').trim());

  form.reset();

  //bot's chatstripe

  const uniqueId = generateUniqueId();
  chatContainer.innerHTML += chatStripe(true, " ", uniqueId);

  chatContainer.scrollTop = chatContainer.scrollHeight;

  const messageDiv = document.getElementById(uniqueId);

  loader(messageDiv);

  //fetch data from server -> bot's response

  let secret_key = generateRandomKey(16) // 16 bytes = 128 bits
  const encrypted_key = await encrypteKey(secret_key, publicKey);

  let private_info = '';
  let encrypted_private_info = '';
  if (sessionStorage.getItem('private_info')) {
    private_info = sessionStorage.getItem('private_info');
    encrypted_private_info = encryptMessage(secret_key, private_info);
    console.log(private_info)
  }
  else {
    encrypted_private_info = '';
  }

  const response = await fetch(`${SERVER_URL}/question/`, {
    method: 'POST',
    credentials: 'include',
    mode: 'cors',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRFToken': getCSRFToken()
    },
    body: JSON.stringify({
      question: data.get('prompt').trim(),
      private_info: encrypted_private_info,
      encrypted_key: encrypted_key,
    })
  });

  if (response.ok) {
    if (response.status === 204) {
      const parsedData = "Câu hỏi không hợp lệ vui lòng thử lại. Chúng tôi chỉ chấp nhận những câu hỏi liên quan đến tập luyện, chế độ dinh dưỡng và sức khỏe.";
      typeText(messageDiv, parsedData);
    }
    else if (response.status === 200) {
      const data = await response.json();
      if (data['valid_question'] === true) {
        const parsedData = data['answer'].trim();
        typeText(messageDiv, parsedData);
      }
    }
  }
  else {
    const err = await response.text();
    messageDiv.innerHTML = "Một lỗi bất ngờ đã xảy ra. Vui lòng thử lại.";
  }
  //clear interval loader
  clearInterval(loadInterval);
  messageDiv.innerHTML = ""
}
//event submit listeners
form.addEventListener('submit', handleSubmit);
form.addEventListener('keyup', (e) => {
  if (e.keyCode === 13) {
    handleSubmit(e);
  }
})